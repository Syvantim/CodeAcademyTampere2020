using System;

namespace OlioOhjelmointi
{
    public class Urheiluauto : Auto
    {
        public bool KattoAlhaalla { get; set; }
    }
}
