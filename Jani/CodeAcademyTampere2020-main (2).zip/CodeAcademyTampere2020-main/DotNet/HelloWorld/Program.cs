﻿using System;

namespace HellWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Moikka Jani!");
        }
    }
}
